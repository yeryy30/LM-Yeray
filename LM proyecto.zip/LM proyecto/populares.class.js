import { API_BASE_URL, API_KEY } from "./constants.js";

export class Cartelera {
    static async getNuevasPelículas(página = 1) {
        const url = `${API_BASE_URL}/3/movie/now_playing?api_key=${API_KEY}&language=es-ES&page=${página}`;
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error("Error en la API");
            const result = await response.json();
            return result.results ?? [];
        } catch (error) {
            console.error(error);
            return [];
        }
    }
}