export const API_BASE_URL = "https://api.themoviedb.org";
export const API_KEY = "TU_API_KEY_AQUI"; // Sustituye por tu clave real
export const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";
