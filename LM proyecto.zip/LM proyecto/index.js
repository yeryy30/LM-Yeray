import { Cartelera } from "./cartelera.class.js";
import { Populares } from "./populares.class.js";
import { Película } from "./peliculas.class.js";

document.addEventListener("DOMContentLoaded", async () => {
    const página = 1;
    try {
        // Cartelera
        const carteleraData = await Cartelera.getNuevasPelículas(página);
        const carteleraPeliculas = carteleraData.map(p => new Película(p));
        renderPeliculas("#cartelera", carteleraPeliculas);

        // Populares
        const popularesData = await Populares.getMásPopulares(página);
        const popularesPeliculas = popularesData.map(p => new Película(p));
        renderPeliculas("#populares", popularesPeliculas);
    } catch (e) {
        mostrarError("No se pudieron cargar las películas.");
    }
});

const renderPeliculas = (selector, peliculas) => {
    const contenedor = document.querySelector(selector);
    if (!contenedor) return;
    contenedor.innerHTML = peliculas.map(p =>
        `<li>
            <img src="${p.imagen}" alt="${p.título}">
            <p>${p.título}</p>
        </li>`
    ).join("");
};

const mostrarError = mensaje => {
    document.body.insertAdjacentHTML("afterbegin", `<div class="alert alert-danger">${mensaje}</div>`);
};