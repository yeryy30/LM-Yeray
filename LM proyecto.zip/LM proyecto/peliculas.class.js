import { IMAGE_BASE } from "./constants.js";

export class Película {
    constructor({ title, poster_path, overview, release_date, vote_average }) {
        this.título = title ?? "Sin título";
        this.imagen = poster_path ? IMAGE_BASE + poster_path : "img/no-image.png";
        this.descripcion = overview ?? "Sin descripción";
        this.fecha = release_date ?? "Sin fecha";
        this.puntuacion = vote_average ?? "N/A";
    }
}